const express = require('express');
const { protect } = require('../middlewares/authMiddleware');
const {
  getAvailableLoads,
  applyForLoad,
  getActiveTrip,
  updateTripStatus,
  getDriverHistory,
  getDriverDashboard,
  submitKYC,
  getProfile,
  updateProfile
} = require('../controllers/driverController');

const router = express.Router();

// Mock auth middleware for now, just sets next()
const softProtect = (req, res, next) => {
  next();
};

router.get('/available-loads', softProtect, getAvailableLoads);
router.post('/apply/:bookingId', softProtect, applyForLoad);
router.get('/active-trip', softProtect, getActiveTrip);
router.patch('/status/:bookingId', softProtect, updateTripStatus);
router.get('/history', softProtect, getDriverHistory);
router.get('/dashboard', softProtect, getDriverDashboard);
router.post('/kyc/submit', softProtect, submitKYC);
router.get('/profile', softProtect, getProfile);
router.put('/profile', softProtect, updateProfile);

module.exports = router;
