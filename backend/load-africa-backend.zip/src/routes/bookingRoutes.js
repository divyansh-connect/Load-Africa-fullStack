const express = require('express');
const { 
  getQuoteRecommendations, 
  createBooking,
  getCustomerBookingsHistory,
  getBookingDetails,
  updateBookingStatus,
  getBookingTimeline
} = require('../controllers/bookingController');
const { protect } = require('../middlewares/authMiddleware');

const router = express.Router();

// Generate quote recommendations based on distance and weight
router.post('/quote', getQuoteRecommendations);

// Using a soft check for creation to allow guests
const softProtect = (req, res, next) => {
  protect(req, res, (err) => {
    next();
  });
};

router.post('/', softProtect, createBooking);

// New Lifecycle Routes
router.get('/history', softProtect, getCustomerBookingsHistory);
router.get('/:id', softProtect, getBookingDetails);
router.patch('/:id/status', softProtect, updateBookingStatus);
router.get('/:id/timeline', softProtect, getBookingTimeline);

module.exports = router;
