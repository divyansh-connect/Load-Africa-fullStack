const express = require('express');
const { verifyPODAndReleasePayment, withdrawEarnings, getWallet } = require('../controllers/financeController');

const router = express.Router();

router.post('/verify-pod/:bookingId', verifyPODAndReleasePayment);
router.post('/withdraw', withdrawEarnings);
router.get('/wallet', getWallet);

module.exports = router;
