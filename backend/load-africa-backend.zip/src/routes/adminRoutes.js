const express = require('express');
const { approveDriverKYC, approveFleetOwner, approveVehicle, approvePlantOwner, approveMachine } = require('../controllers/adminController');

const router = express.Router();

router.post('/kyc/approve/:driverId', approveDriverKYC);
router.post('/fleet/approve/:fleetId', approveFleetOwner);
router.post('/vehicle/approve/:vehicleId', approveVehicle);
router.post('/plant/approve/:plantId', approvePlantOwner);
router.post('/machine/approve/:machineId', approveMachine);

module.exports = router;
