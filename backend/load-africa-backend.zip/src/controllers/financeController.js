const { prisma } = require('../config/db');

// Helper for dev, assuming user id is driver id for now.
const getDriverId = async (req) => {
  if (req.user?.driver?.id) return req.user.driver.id;
  const driver = await prisma.driver.findFirst();
  return driver ? driver.id : null;
};

const verifyPODAndReleasePayment = async (req, res) => {
  try {
    const { bookingId } = req.params;

    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        assignments: {
          include: { driver: { include: { user: true } } }
        },
        quotes: true
      }
    });

    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    if (booking.status !== 'POD_UPLOADED') {
      return res.status(400).json({ success: false, message: 'Booking is not awaiting POD verification' });
    }

    const assignment = booking.assignments[0];
    if (!assignment) return res.status(400).json({ success: false, message: 'No driver assigned' });

    // Use quote grand total for driver payout simulation
    const payoutAmount = booking.quotes[0]?.grand_total || 1500;

    await prisma.$transaction(async (tx) => {
      // 1. Mark booking as COMPLETED
      await tx.booking.update({
        where: { id: bookingId },
        data: { status: 'COMPLETED' }
      });

      // 2. Add to Tracking
      await tx.trackingHistory.create({
        data: { booking_id: bookingId, status: 'COMPLETED', remarks: 'Broker verified POD. Trip complete.' }
      });

      // 3. Update or Create Driver Wallet
      let wallet = await tx.wallet.findFirst({ where: { user_id: assignment.driver.user_id } });
      if (!wallet) {
        wallet = await tx.wallet.create({ data: { user_id: assignment.driver.user_id, balance: 0 } });
      }

      await tx.wallet.update({
        where: { id: wallet.id },
        data: { balance: { increment: payoutAmount } }
      });

      // 4. Create Wallet Transaction
      await tx.walletTransaction.create({
        data: {
          wallet_id: wallet.id,
          type: 'CREDIT',
          amount: payoutAmount,
          description: `Payout for booking ${bookingId}`,
          reference_id: bookingId,
          status: 'COMPLETED'
        }
      });
    });

    res.status(200).json({ success: true, message: 'POD Verified and Payment Released' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const withdrawEarnings = async (req, res) => {
  try {
    const driverId = await getDriverId(req);
    const { amount } = req.body;
    
    if (!driverId) return res.status(404).json({ success: false, message: 'Driver not found' });

    const driver = await prisma.driver.findUnique({ where: { id: driverId }, include: { user: true } });

    await prisma.$transaction(async (tx) => {
      const wallet = await tx.wallet.findFirst({ where: { user_id: driver.user_id } });
      
      if (!wallet || wallet.balance < amount) {
        throw new Error("Insufficient funds");
      }

      await tx.wallet.update({
        where: { id: wallet.id },
        data: { balance: { decrement: amount } }
      });

      await tx.walletTransaction.create({
        data: {
          wallet_id: wallet.id,
          type: 'DEBIT',
          amount: amount,
          description: `Withdrawal to bank account`,
          status: 'COMPLETED'
        }
      });
    });

    res.status(200).json({ success: true, message: 'Withdrawal successful' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getWallet = async (req, res) => {
  try {
    const driverId = await getDriverId(req);
    const driver = await prisma.driver.findUnique({ where: { id: driverId }, include: { user: true } });
    
    let wallet = await prisma.wallet.findFirst({ 
      where: { user_id: driver.user_id },
      include: { transactions: { orderBy: { created_at: 'desc' } } }
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: { user_id: driver.user_id, balance: 0 },
        include: { transactions: true }
      });
    }

    res.status(200).json({ success: true, data: wallet });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
}

module.exports = {
  verifyPODAndReleasePayment,
  withdrawEarnings,
  getWallet
};
