const { prisma } = require('../config/db');

const approveDriverKYC = async (req, res) => {
  try {
    const { driverId } = req.params;

    // Typically this would be protected by admin auth middleware.
    
    const driver = await prisma.driver.update({
      where: { id: driverId },
      data: {
        status: 'ACTIVE' // Approved and Active in the marketplace
      }
    });

    res.status(200).json({ success: true, data: driver });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const approveFleetOwner = async (req, res) => {
  try {
    const { fleetId } = req.params;
    const fleetOwner = await prisma.fleetOwner.update({
      where: { id: fleetId },
      data: { status: 'ACTIVE' }
    });
    res.status(200).json({ success: true, data: fleetOwner });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const approveVehicle = async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const vehicle = await prisma.vehicle.update({
      where: { id: vehicleId },
      data: { status: 'AVAILABLE' } // Approved and ready
    });
    res.status(200).json({ success: true, data: vehicle });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const approvePlantOwner = async (req, res) => {
  try {
    const { plantId } = req.params;
    const plantOwner = await prisma.plantOwner.update({
      where: { id: plantId },
      data: { status: 'ACTIVE' }
    });
    await prisma.auditLog.create({
      data: { entity_type: 'PlantOwner', entity_id: plantId, action: 'APPROVED', new_value: 'ACTIVE' }
    });
    res.status(200).json({ success: true, data: plantOwner });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const approveMachine = async (req, res) => {
  try {
    const { machineId } = req.params;
    const machine = await prisma.machine.update({
      where: { id: machineId },
      data: { status: 'APPROVED' }
    });
    await prisma.auditLog.create({
      data: { entity_type: 'Machine', entity_id: machineId, action: 'APPROVED', new_value: 'APPROVED' }
    });
    res.status(200).json({ success: true, data: machine });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

module.exports = {
  approveDriverKYC,
  approveFleetOwner,
  approveVehicle,
  approvePlantOwner,
  approveMachine
};
